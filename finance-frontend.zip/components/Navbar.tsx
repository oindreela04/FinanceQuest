'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function Navbar() {
  const path = usePathname()
  return (
    <nav className="bg-white border-b">
      <div className="max-w-5xl mx-auto p-4 flex items-center justify-between">
        <Link href="/" className="font-bold">FinanceQuest</Link>
        <div className="flex gap-3 items-center">
          <Link href="/dashboard" className={path === '/dashboard' ? 'text-blue-600' : ''}>Dashboard</Link>
          <Link href="/portfolio" className={path === '/portfolio' ? 'text-blue-600' : ''}>Portfolio</Link>
          <Link href="/market" className={path === '/market' ? 'text-blue-600' : ''}>Market</Link>
          <Link href="/login" className="px-3 py-1 border rounded">Login</Link>
        </div>
      </div>
    </nav>
  )
}
