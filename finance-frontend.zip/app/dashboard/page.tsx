'use client'
import { useEffect, useState } from 'react'
import axios from 'axios'
import Link from 'next/link'

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const token = typeof window !== 'undefined' ? localStorage.getItem('fq_token') : null

  useEffect(() => {
    if (!token) return
    axios.get(`${process.env.NEXT_PUBLIC_API_URL}/users/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setUser(res.data))
      .catch(()=>{})
  }, [token])

  return (
    <div>
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p className="text-gray-600">Welcome back{user ? `, ${user.name}` : ''}.</p>

      <section className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="p-4 border rounded">
          <h3 className="font-semibold">Portfolios</h3>
          <Link href="/portfolio" className="text-blue-600">Manage portfolios</Link>
        </div>

        <div className="p-4 border rounded">
          <h3 className="font-semibold">Markets</h3>
          <Link href="/market" className="text-blue-600">Search symbols & quotes</Link>
        </div>
      </section>
    </div>
  )
}
