'use client'
import { useState } from 'react'
import axios from 'axios'

export default function MarketPage() {
  const [q, setQ] = useState('')
  const [results, setResults] = useState<any>(null)

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault()
    if (!q) return
    const res = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/market/search?q=${encodeURIComponent(q)}`)
    setResults(res.data)
  }

  return (
    <div>
      <h1 className="text-2xl font-bold">Market</h1>
      <form onSubmit={handleSearch} className="mt-4 flex gap-2">
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search symbol or company" className="p-2 border rounded flex-1" />
        <button className="px-4 py-2 bg-blue-600 text-white rounded">Search</button>
      </form>

      <pre className="mt-4 p-4 border rounded overflow-auto">{JSON.stringify(results, null, 2)}</pre>
    </div>
  )
}
