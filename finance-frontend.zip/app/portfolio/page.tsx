'use client'
import { useEffect, useState } from 'react'
import axios from 'axios'

export default function PortfolioPage() {
  const [portfolios, setPortfolios] = useState<any[]>([])
  const token = typeof window !== 'undefined' ? localStorage.getItem('fq_token') : null

  useEffect(() => {
    if (!token) return
    axios.get(`${process.env.NEXT_PUBLIC_API_URL}/portfolio`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setPortfolios(res.data))
      .catch(()=>{})
  }, [token])

  return (
    <div>
      <h1 className="text-2xl font-bold">Portfolios</h1>
      <div className="mt-4 space-y-4">
        {portfolios.length === 0 && <div className="p-4 border rounded">You have no portfolios yet.</div>}
        {portfolios.map(p => (
          <div key={p.id} className="p-4 border rounded">
            <h3 className="font-semibold">{p.name}</h3>
            <p>Cash: {p.cashBalance}</p>
            <div className="mt-2">Positions: {p.positions?.length || 0}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
