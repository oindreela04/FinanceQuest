import Link from 'next/link'

export default function Home() {
  return (
    <section className="space-y-6">
      <h1 className="text-4xl font-bold">FinanceQuest</h1>
      <p className="text-gray-600">Level up your money game — track portfolios, paper trade, and follow the market.</p>

      <div className="flex gap-4">
        <Link href="/login" className="px-4 py-2 bg-blue-600 text-white rounded">Login</Link>
        <Link href="/register" className="px-4 py-2 border rounded">Register</Link>
      </div>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="p-4 border rounded">Live quotes and watchlist</div>
        <div className="p-4 border rounded">Portfolio overview</div>
        <div className="p-4 border rounded">News & insights</div>
      </section>
    </section>
  )
}
