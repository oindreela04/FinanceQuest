# FinanceQuest Frontend

Next.js 14 + TailwindCSS frontend scaffold that integrates with the FinanceQuest backend.

Quick start:
1. Copy `.env.example` to `.env.local` and set `NEXT_PUBLIC_API_URL`.
2. Install deps: `npm install`
3. Run dev: `npm run dev`
