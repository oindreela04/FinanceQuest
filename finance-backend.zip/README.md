# FinanceQuest Backend

This repository contains the backend for FinanceQuest — an educational/paper-trading finance app.

## Quick start

1. Copy `.env.example` to `.env` and fill values.
2. Install dependencies:
   ```
   npm install
   ```
3. Generate Prisma client and migrate:
   ```
   npx prisma generate
   npx prisma migrate dev --name init
   npm run seed
   ```
4. Start dev server:
   ```
   npm run dev
   ```

API endpoints:
- `POST /api/auth/register` — register
- `POST /api/auth/login` — login
- `GET /api/users/me` — get current user
- `POST /api/portfolio` — create portfolio
- `GET /api/portfolio` — list portfolios
- `POST /api/portfolio/buy` — buy position
- `POST /api/portfolio/sell` — sell position
- `GET /api/market/quote?symbol=...` — get quote (requires FINNHUB_API_KEY)

