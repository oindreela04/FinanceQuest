import { Router } from "express";
import { requireAuth } from "../middleware/authMiddleware";
import { createPortfolio, getPortfolios, buyPosition, sellPosition } from "../controllers/portfolioController";

const router = Router();

router.use(requireAuth);

router.post("/", createPortfolio);
router.get("/", getPortfolios);
router.post("/buy", buyPosition);
router.post("/sell", sellPosition);

export default router;
