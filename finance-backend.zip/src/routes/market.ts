import { Router } from "express";
import { quote, symbolSearch } from "../controllers/marketController";

const router = Router();

router.get("/quote", quote);
router.get("/search", symbolSearch);

export default router;
