export async function sendEmail(to: string, subject: string, text: string) {
  // Stub: integrate nodemailer or any email provider in production.
  console.log("sendEmail stub:", to, subject, text);
  return true;
}
