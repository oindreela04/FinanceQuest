import fetch from "node-fetch";

const provider = process.env.MARKET_API_PROVIDER || "FINNHUB";

export async function getQuote(symbol: string) {
  if (provider === "FINNHUB") {
    const key = process.env.FINNHUB_API_KEY;
    const res = await fetch(`https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${key}`);
    return res.json();
  }
  throw new Error("Market provider not configured");
}

export async function searchSymbols(query: string) {
  if (provider === "FINNHUB") {
    const key = process.env.FINNHUB_API_KEY;
    const res = await fetch(`https://finnhub.io/api/v1/search?q=${encodeURIComponent(query)}&token=${key}`);
    return res.json();
  }
  throw new Error("Market provider not configured");
}
