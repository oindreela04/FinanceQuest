import { Request, Response } from "express";
import { getQuote, searchSymbols } from "../services/marketService";

export const quote = async (req: Request, res: Response) => {
  const symbol = req.query.symbol as string;
  if (!symbol) return res.status(400).json({ message: "Symbol required" });
  try {
    const data = await getQuote(symbol);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ message: err.message || "Market error" });
  }
};

export const symbolSearch = async (req: Request, res: Response) => {
  const q = req.query.q as string;
  if (!q) return res.status(400).json({ message: "Query required" });
  try {
    const data = await searchSymbols(q);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ message: err.message || "Market error" });
  }
};
