import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const createPortfolio = async (req: any, res: Response) => {
  const userId = req.user.id;
  const { name, initialCash = 0 } = req.body;

  const portfolio = await prisma.portfolio.create({
    data: { userId, name, cashBalance: initialCash },
  });

  if (initialCash > 0) {
    await prisma.transaction.create({
      data: {
        userId,
        portfolioId: portfolio.id,
        type: "DEPOSIT",
        amount: initialCash,
      },
    });
  }

  res.json(portfolio);
};

export const getPortfolios = async (req: any, res: Response) => {
  const userId = req.user.id;
  const portfolios = await prisma.portfolio.findMany({
    where: { userId },
    include: { positions: true },
  });
  res.json(portfolios);
};

export const buyPosition = async (req: any, res: Response) => {
  const userId = req.user.id;
  const { portfolioId, symbol, quantity, price } = req.body;
  if (!portfolioId || !symbol || !quantity || !price) return res.status(400).json({ message: "Missing fields" });

  const portfolio = await prisma.portfolio.findUnique({ where: { id: portfolioId } });
  if (!portfolio || (portfolio as any).userId !== userId) return res.status(404).json({ message: "Portfolio not found" });

  const cost = quantity * price;
  if ((portfolio as any).cashBalance < cost) return res.status(400).json({ message: "Insufficient cash" });

  const existing = await prisma.position.findFirst({
    where: { portfolioId, symbol },
  });

  if (existing) {
    const newQty = existing.quantity + quantity;
    const newAvg = ((existing.avgPrice * existing.quantity) + (price * quantity)) / newQty;
    await prisma.position.update({
      where: { id: existing.id },
      data: { quantity: newQty, avgPrice: newAvg },
    });
  } else {
    await prisma.position.create({
      data: { portfolioId, symbol, quantity, avgPrice: price },
    });
  }

  await prisma.portfolio.update({
    where: { id: portfolioId },
    data: { cashBalance: { decrement: cost } },
  });

  await prisma.transaction.create({
    data: {
      userId,
      portfolioId,
      symbol,
      type: "BUY",
      quantity,
      price,
      amount: cost,
    },
  });

  res.json({ message: "Bought", symbol, quantity, price });
};

export const sellPosition = async (req: any, res: Response) => {
  const userId = req.user.id;
  const { portfolioId, symbol, quantity, price } = req.body;
  if (!portfolioId || !symbol || !quantity || !price) return res.status(400).json({ message: "Missing fields" });

  const portfolio = await prisma.portfolio.findUnique({ where: { id: portfolioId } });
  if (!portfolio || (portfolio as any).userId !== userId) return res.status(404).json({ message: "Portfolio not found" });

  const existing = await prisma.position.findFirst({ where: { portfolioId, symbol } });
  if (!existing || existing.quantity < quantity) return res.status(400).json({ message: "Not enough shares" });

  const proceeds = quantity * price;
  const remainingQty = existing.quantity - quantity;

  if (remainingQty === 0) {
    await prisma.position.delete({ where: { id: existing.id } });
  } else {
    await prisma.position.update({ where: { id: existing.id }, data: { quantity: remainingQty } });
  }

  await prisma.portfolio.update({
    where: { id: portfolioId },
    data: { cashBalance: { increment: proceeds } },
  });

  await prisma.transaction.create({
    data: {
      userId,
      portfolioId,
      symbol,
      type: "SELL",
      quantity,
      price,
      amount: proceeds,
    },
  });

  res.json({ message: "Sold", symbol, quantity, price });
};
