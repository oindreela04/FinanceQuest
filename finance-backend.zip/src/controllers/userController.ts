import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const getMe = async (req: any, res: Response) => {
  const userId = req.user.id;
  const user = await prisma.user.findUnique({ where: { id: userId }, include: { portfolios: true, watchlist: true } });
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json(user);
};
