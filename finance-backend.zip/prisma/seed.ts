import { PrismaClient } from "@prisma/client";
import bcrypt from "bcrypt";

const prisma = new PrismaClient();

async function main() {
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash("demo1234", salt);

  await prisma.user.upsert({
    where: { email: "demo@financequest.app" },
    update: {},
    create: {
      email: "demo@financequest.app",
      name: "Demo User",
      passwordHash: hash
    }
  });

  console.log("Seed finished.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
